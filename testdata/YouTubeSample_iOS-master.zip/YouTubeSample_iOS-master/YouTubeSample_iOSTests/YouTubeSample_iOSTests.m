//
//  YouTubeSample_iOSTests.m
//  YouTubeSample_iOSTests
//
//  Created by Manuel Carrasco Molina on 08.01.12.
//  Copyright (c) 2012 Pomcast. All rights reserved.
//

#import "YouTubeSample_iOSTests.h"

@implementation YouTubeSample_iOSTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in YouTubeSample_iOSTests");
}

@end
