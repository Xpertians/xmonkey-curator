//
//  YouTubeSample_iOSTests.h
//  YouTubeSample_iOSTests
//
//  Created by Manuel Carrasco Molina on 08.01.12.
//  Copyright (c) 2012 Pomcast. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface YouTubeSample_iOSTests : SenTestCase

@end
